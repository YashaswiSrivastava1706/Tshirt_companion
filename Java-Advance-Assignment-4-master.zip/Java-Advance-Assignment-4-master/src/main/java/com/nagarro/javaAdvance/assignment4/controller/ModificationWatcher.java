package com.nagarro.javaAdvance.assignment4.controller;

import com.nagarro.javaAdvance.assignment4.dao.TshirtNTshirtBrandDao;
import com.nagarro.javaAdvance.assignment4.model.*;
import com.nagarro.javaAdvance.assignment4.util.AppContextUtil;

import java.io.File;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Set;

public class ModificationWatcher  implements Runnable {
    static HashMap<String, Long> lastModifiedAt = new HashMap<>();
    File dir = new File("C:\\trainig_yashaswi\\Java\\Java-Advance-Assignment-4-master\\CSV/");

    static TshirtNTshirtBrandDao tshirtDao = (TshirtNTshirtBrandDao) AppContextUtil.context.getBean("tshirtDao");


    public void run() {
//    	System.out.println("Here it comes 1");

        File[] files = dir.listFiles();
        ArrayList<String> listOfFileNames = new ArrayList<>();
//    	System.out.println("Here it comes 2");
//    	System.out.println(files);
//    	System.out.println("Here it comes 5");
//
//    	

        for (File file : files) {
        	System.out.println(file);

//        	System.out.println("Here it comes 3");

            if ((!(lastModifiedAt.containsKey(file.getName()))) || (file.lastModified() > lastModifiedAt.get(file.getName()))) {

                TshirtBrand tshirtbrand = ReadTshirtBrandFromFile.readFile(file);
                if (lastModifiedAt.containsKey(file.getName())) {

                    tshirtDao.deleteTshirtBrand(file.getName());
                }
                tshirtDao.saveTshirtBrand(tshirtbrand);
                lastModifiedAt.put(file.getName(), file.lastModified());
            }
           listOfFileNames.add(file.getName());
        }
    	
    	
//    	System.out.println("Here it comes 4");

        Set<String> fileNamesOfPast = new HashSet<>(lastModifiedAt.keySet());
        if (fileNamesOfPast.size() == listOfFileNames.size())
            return;
        for (String string : fileNamesOfPast) {
            if (!(listOfFileNames.contains(string))) {
                tshirtDao.deleteTshirtBrand(string);
                lastModifiedAt.remove(string);
            }
        }
    }
}
