package com.nagarro.javaAdvance.assignment4.model;

import javax.persistence.*;

@Entity
public class Tshirt {
    @Id
    @GeneratedValue
    private int id;
    private String Tshirtid;
    private String name;
    private String color;
    private String gender;
    private String size;
    private double price;
    private double rating;
    private boolean availability;
    @ManyToOne
    private TshirtBrand tshirtbrand;

    public Tshirt() {

    }

    public Tshirt(String Tshirtid, String name, String color, String gender, 
    				String size, double price, double rating,
                  boolean availability, TshirtBrand tshirtbrand) {
        super();
        this.Tshirtid = Tshirtid;
        this.name = name;
        this.color = color;
        this.gender = gender;
        this.size = size;
        this.price = price;
        this.rating = rating;
        this.availability = availability;
        this.tshirtbrand=tshirtbrand;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }
    
    public String getTshirtid() {
        return Tshirtid;
    }

    public void setTshirtid(String Tshirtid) {
        this.Tshirtid =Tshirtid;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name =name;
    }

    public String getColor() {
        return color;
    }

    public void setColor(String color) {
        this.color = color;
    }
    
    public String getGender() {
        return gender;
    }

    public void setGender(String gender) {
        this.gender = gender;
    }
    
    public String getSize() {
        return size;
    }

    public void setSize(String size) {
        this.size = size;
    }

    public double getPrice() {
        return price;
    }

    public void setPrice(double price) {
        this.price =price;
    }

    public double getRating() {
        return rating;
    }

    public void setRating(double rating) {
        this.rating = rating;
    }

    public boolean isAvailability() {
        return availability;
    }

    public void setAvailability(boolean availability) {
        this.availability = availability;
    }


    public TshirtBrand getTshirtBrand() {
        return tshirtbrand;
    }

    public void setTshirtBrand(TshirtBrand tshirtbrand) {
        this.tshirtbrand = tshirtbrand;
    }

}
