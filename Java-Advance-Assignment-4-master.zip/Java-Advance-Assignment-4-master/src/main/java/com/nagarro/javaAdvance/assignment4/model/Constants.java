package com.nagarro.javaAdvance.assignment4.model;

import java.io.File;
import java.text.SimpleDateFormat;

public class Constants {
    public static final File dir = new File("CSV/");
    public static final SimpleDateFormat dateFormat = new SimpleDateFormat("dd-MM-yyyy");
}
