package com.nagarro.javaAdvance.assignment4.controller;

import com.nagarro.javaAdvance.assignment4.model.TshirtBrand;
import com.nagarro.javaAdvance.assignment4.model.Tshirt;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashSet;
import java.util.StringTokenizer;

public class ReadTshirtBrandFromFile {
    public static final SimpleDateFormat dateFormat = new SimpleDateFormat("dd-MM-yyyy");

    public static TshirtBrand readFile(File file) {
        BufferedReader reader = null;
        TshirtBrand tshirtbrand = new TshirtBrand();
        tshirtbrand.setName(file.getName());
        HashSet<Tshirt> tshirt_Set = new HashSet<>();
        try {
            reader = new BufferedReader(new FileReader(file));
            String line = reader.readLine();
            line = reader.readLine();

            while (line != null) {
                Tshirt f = manipulateLine(line, tshirtbrand);
                line = reader.readLine();
                tshirt_Set.add(f);
            }
        } catch (Exception e) {
            System.err.println("Could Not Read the File");
        } finally {
            if (reader != null) {
                try {
                    reader.close();
                } catch (Exception e) {
                    System.err.println("Could Not Close the File");
                }
            }
        }
        tshirtbrand.setTshirts(tshirt_Set);
        return tshirtbrand;
    }

    private static Tshirt manipulateLine(String line, TshirtBrand aObj) {

        StringTokenizer st = new StringTokenizer(line, "|");

        String Tshirtid = st.nextToken();
        String name = st.nextToken();
        String color = st.nextToken();
        
        String gender = st.nextToken();
        
        String size = st.nextToken();
        
        double price = Double.parseDouble(st.nextToken());
        double rating = Double.parseDouble(st.nextToken());

        
        String avail = st.nextToken();
        boolean availability;
        availability = avail.charAt(0) == 'Y';
        
        
        return new Tshirt(Tshirtid, name, color, gender, size,
                price, rating, availability, aObj);
    }
}
