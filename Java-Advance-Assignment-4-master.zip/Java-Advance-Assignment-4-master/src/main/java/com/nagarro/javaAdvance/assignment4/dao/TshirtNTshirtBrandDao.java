package com.nagarro.javaAdvance.assignment4.dao;

import com.nagarro.javaAdvance.assignment4.model.TshirtBrand;
import com.nagarro.javaAdvance.assignment4.model.Tshirt;

import java.util.List;

public interface TshirtNTshirtBrandDao {
    public void saveTshirtBrand(TshirtBrand tshirtbrand);

    public List<Tshirt> getTshirts();

    public void deleteTshirtBrand(String tshirtBrandName);
}
