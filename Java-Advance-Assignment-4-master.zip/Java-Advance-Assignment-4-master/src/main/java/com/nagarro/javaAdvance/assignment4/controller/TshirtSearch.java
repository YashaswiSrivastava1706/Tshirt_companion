package com.nagarro.javaAdvance.assignment4.controller;

import com.nagarro.javaAdvance.assignment4.model.Tshirt;
import com.nagarro.javaAdvance.assignment4.model.TshirtDetailsEntered;

import org.springframework.beans.propertyeditors.CustomDateEditor;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.WebDataBinder;
import org.springframework.web.bind.annotation.InitBinder;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import jakarta.validation.Valid;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

@Controller
public class TshirtSearch {

//    @InitBinder
//    public void initBinder(WebDataBinder binder) {
//        SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
//        binder.registerCustomEditor(Date.class, "flightDate", new CustomDateEditor(dateFormat, false));
//    }

    @RequestMapping(value = "/tshirtSearch", method = RequestMethod.GET)
    public ModelAndView getTshirtSearch() {
        return new ModelAndView("tshirtSearch");
    }

    @RequestMapping(value = "/tshirtSearch", method = RequestMethod.POST)
    public ModelAndView tshirtSearch(
    		
            @Valid @ModelAttribute("tshirtDetails") TshirtDetailsEntered tshirtDetails, BindingResult result) {

        ModelAndView modelAndView = new ModelAndView("tshirtSearch");
        if (result.hasErrors()) {
            System.err.println(result);
            return modelAndView;
        }
        List<Tshirt> listOfMatchingTshirts = tshirtDetails.getListOfMatchingTshirts();
        modelAndView = new ModelAndView("tshirtList");
        modelAndView.addObject("list", listOfMatchingTshirts);
        return modelAndView;
    }
}
