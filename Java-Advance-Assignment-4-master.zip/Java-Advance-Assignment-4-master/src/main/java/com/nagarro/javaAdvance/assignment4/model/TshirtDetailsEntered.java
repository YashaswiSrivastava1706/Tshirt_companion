package com.nagarro.javaAdvance.assignment4.model;

import com.nagarro.javaAdvance.assignment4.dao.TshirtNTshirtBrandDao;
import com.nagarro.javaAdvance.assignment4.util.AppContextUtil;
import com.nagarro.javaAdvance.assignment4.util.TshirtRatingComparator;
import com.nagarro.javaAdvance.assignment4.util.TshirtPriceComparator;

import jakarta.validation.constraints.*;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Date;
import java.util.List;

public class TshirtDetailsEntered {
    private String color;

    private String gender;

    private String size;

    @Max(value = 2, message = "Choose valid entry")
    @Min(value = 1, message = "is required")
    private int outputPreference;

    public String getColor() {
        return color;
    }

    public void setColor(String color) {
        this.color =color;
    }

    public String getSize() {
        return size;
    }

    public void setSize(String size) {
        this.size = size;
    }

    public String getGender() {
        return gender;
    }

    public void setGender(String gender) {
        this.gender = gender;
    }

   

    public int getOutputPreference() {
        return outputPreference;
    }

    public void setOutputPreference(int outputPreference) {
        this.outputPreference = outputPreference;
    }

    public List<Tshirt> getListOfMatchingTshirts() {
        TshirtNTshirtBrandDao tshirtDao = (TshirtNTshirtBrandDao) AppContextUtil.context.getBean("tshirtDao");
        List<Tshirt> allTshirts = tshirtDao.getTshirts();
        ArrayList<Tshirt> matchingTshirts = new ArrayList<>();

        for (Tshirt tshirt : allTshirts) {
            if (tshirt.getColor().equalsIgnoreCase(getColor())
                    && tshirt.getSize().equalsIgnoreCase(getSize())
                    && tshirt.getGender().equalsIgnoreCase(getGender())
                    && tshirt.isAvailability())
                matchingTshirts.add(tshirt);
        }
//        System.out.println("Here 3");
        if (getOutputPreference() == 1)
            Collections.sort(matchingTshirts, new TshirtPriceComparator());
        else
            Collections.sort(matchingTshirts, new TshirtRatingComparator());

        return matchingTshirts;
    }
}
