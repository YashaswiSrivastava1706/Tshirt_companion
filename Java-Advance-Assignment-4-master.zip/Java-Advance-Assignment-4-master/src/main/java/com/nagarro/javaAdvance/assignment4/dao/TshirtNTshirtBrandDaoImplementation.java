package com.nagarro.javaAdvance.assignment4.dao;

import com.nagarro.javaAdvance.assignment4.model.TshirtBrand;
import com.nagarro.javaAdvance.assignment4.model.Tshirt;
import org.hibernate.Session;
import org.springframework.orm.hibernate5.HibernateTemplate;

import javax.persistence.NoResultException;
import javax.persistence.TypedQuery;
import java.util.List;

public class TshirtNTshirtBrandDaoImplementation implements TshirtNTshirtBrandDao {

    HibernateTemplate template;

    public void setTemplate(HibernateTemplate template) {
        this.template = template;
    }

    public void saveTshirtBrand(TshirtBrand tshirtbrand) {
        Session session = template.getSessionFactory().openSession();
        session.beginTransaction();
        session.save(tshirtbrand);
        session.getTransaction().commit();
        session.close();
    }

    public List<Tshirt> getTshirts() {
        return template.loadAll(Tshirt.class);
    }

    public void deleteTshirtBrand(String tshirtBrandName) {
        Session session = template.getSessionFactory().openSession();
        session.beginTransaction();

        @SuppressWarnings("unchecked")
        TypedQuery<TshirtBrand> query = session.createQuery("from TshirtBrand where name = :string");
        query.setParameter("string", tshirtBrandName);
        try {
            TshirtBrand tshirtbrand = query.getSingleResult();
            tshirtbrand = session.load(TshirtBrand.class, tshirtbrand.getId());
            session.delete(tshirtbrand);
            session.getTransaction().commit();
            session.close();
        } catch (NoResultException e) {
            System.err.println("No Tshirt Brand Found");
        }
    }
}
